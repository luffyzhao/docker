#ifndef DS_PAIR_HANDLERS_H
#define DS_PAIR_HANDLERS_H

#include "php.h"

extern zend_object_handlers php_pair_handlers;

void php_ds_register_pair_handlers();

#endif
